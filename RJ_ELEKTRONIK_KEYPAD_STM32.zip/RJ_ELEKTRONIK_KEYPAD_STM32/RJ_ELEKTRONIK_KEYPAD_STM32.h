/**
  * @file    RJ_ELEKTRONIK_KEYPAD_STM32.h
  * @brief   Keypad 4x4 driver for STM32
  * @author  Renaty
  * @date    Apr 6, 2025
  */
#ifndef INC_RJ_ELEKTRONIK_KEYPAD_STM32_H_
#define INC_RJ_ELEKTRONIK_KEYPAD_STM32_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"

// Nombre de lignes et colonnes du clavier
#define ROW_NUMBER 4
#define COL_NUMBER 4

// Structure pour gérer l'état du clavier
typedef struct {
    GPIO_TypeDef* row_ports[ROW_NUMBER];  // Ports GPIO des lignes
    uint16_t row_pins[ROW_NUMBER];        // Pins des lignes
    GPIO_TypeDef* col_ports[COL_NUMBER];  // Ports GPIO des colonnes
    uint16_t col_pins[COL_NUMBER];        // Pins des colonnes
} KEYPAD_HandleTypeDef;

// Tableau de correspondance touches/caractères
extern const uint8_t KEYPAD_MAP[ROW_NUMBER][COL_NUMBER];

// Initialise le clavier avec les broches spécifiées
void KEYPAD_Init(KEYPAD_HandleTypeDef *keypad,
                GPIO_TypeDef* row1_port, uint16_t row1_pin,
                GPIO_TypeDef* row2_port, uint16_t row2_pin,
                GPIO_TypeDef* row3_port, uint16_t row3_pin,
                GPIO_TypeDef* row4_port, uint16_t row4_pin,
                GPIO_TypeDef* col1_port, uint16_t col1_pin,
                GPIO_TypeDef* col2_port, uint16_t col2_pin,
                GPIO_TypeDef* col3_port, uint16_t col3_pin,
                GPIO_TypeDef* col4_port, uint16_t col4_pin);

// Fonctions d'interaction avec le clavier
char KEYPAD_GetKey(KEYPAD_HandleTypeDef *keypad);
uint8_t KEYPAD_IsKeyPressed(KEYPAD_HandleTypeDef *keypad);

#ifdef __cplusplus
}
#endif

#endif /* INC_RJ_ELEKTRONIK_KEYPAD_STM32_H_ */
