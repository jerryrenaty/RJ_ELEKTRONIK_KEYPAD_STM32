/**
  * @file    RJ_ELEKTRONIK_KEYPAD_STM32.c
  * @brief   Keypad 4x4 driver implementation
  * @author  Renat
  * @date    Apr 6, 2025
  */
#include "RJ_ELEKTRONIK_KEYPAD_STM32.h"

// Correspondance entre positions physiques et caractères
const uint8_t KEYPAD_MAP[ROW_NUMBER][COL_NUMBER] = {
    {'1', '2', '3', 'A'},  // Ligne 0
    {'4', '5', '6', 'B'},  // Ligne 1
    {'7', '8', '9', 'C'},  // Ligne 2
    {'*', '0', '#', 'D'}   // Ligne 3
};

// Configure les broches GPIO pour le clavier
void KEYPAD_Init(KEYPAD_HandleTypeDef *keypad,
                GPIO_TypeDef* row1_port, uint16_t row1_pin,
                GPIO_TypeDef* row2_port, uint16_t row2_pin,
                GPIO_TypeDef* row3_port, uint16_t row3_pin,
                GPIO_TypeDef* row4_port, uint16_t row4_pin,
                GPIO_TypeDef* col1_port, uint16_t col1_pin,
                GPIO_TypeDef* col2_port, uint16_t col2_pin,
                GPIO_TypeDef* col3_port, uint16_t col3_pin,
                GPIO_TypeDef* col4_port, uint16_t col4_pin)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // Enregistre la configuration des broches
    keypad->row_ports[0] = row1_port; keypad->row_pins[0] = row1_pin;
    keypad->row_ports[1] = row2_port; keypad->row_pins[1] = row2_pin;
    keypad->row_ports[2] = row3_port; keypad->row_pins[2] = row3_pin;
    keypad->row_ports[3] = row4_port; keypad->row_pins[3] = row4_pin;

    keypad->col_ports[0] = col1_port; keypad->col_pins[0] = col1_pin;
    keypad->col_ports[1] = col2_port; keypad->col_pins[1] = col2_pin;
    keypad->col_ports[2] = col3_port; keypad->col_pins[2] = col3_pin;
    keypad->col_ports[3] = col4_port; keypad->col_pins[3] = col4_pin;

    // Configure les lignes en sortie
    for(uint8_t i = 0; i < ROW_NUMBER; i++) {
        GPIO_InitStruct.Pin = keypad->row_pins[i];
        GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
        GPIO_InitStruct.Pull = GPIO_NOPULL;
        GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
        HAL_GPIO_Init(keypad->row_ports[i], &GPIO_InitStruct);
        HAL_GPIO_WritePin(keypad->row_ports[i], keypad->row_pins[i], GPIO_PIN_SET);
    }

    // Configure les colonnes en entrée avec pull-up
    for(uint8_t i = 0; i < COL_NUMBER; i++) {
        GPIO_InitStruct.Pin = keypad->col_pins[i];
        GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
        GPIO_InitStruct.Pull = GPIO_PULLUP;
        HAL_GPIO_Init(keypad->col_ports[i], &GPIO_InitStruct);
    }
}

// Vérifie si une touche est actuellement pressée
uint8_t KEYPAD_IsKeyPressed(KEYPAD_HandleTypeDef *keypad) {
    for(uint8_t i = 0; i < ROW_NUMBER; i++) {
        // Active la ligne courante
        HAL_GPIO_WritePin(keypad->row_ports[i], keypad->row_pins[i], GPIO_PIN_RESET);

        // Vérifie chaque colonne
        for(uint8_t j = 0; j < COL_NUMBER; j++) {
            if(HAL_GPIO_ReadPin(keypad->col_ports[j], keypad->col_pins[j]) == GPIO_PIN_RESET) {
                HAL_GPIO_WritePin(keypad->row_ports[i], keypad->row_pins[i], GPIO_PIN_SET);
                return 1;
            }
        }
        // Désactive la ligne
        HAL_GPIO_WritePin(keypad->row_ports[i], keypad->row_pins[i], GPIO_PIN_SET);
    }
    return 0;
}

// Lit une touche avec gestion de l'antirebond
char KEYPAD_GetKey(KEYPAD_HandleTypeDef *keypad) {
    for(uint8_t i = 0; i < ROW_NUMBER; i++) {
        // Active la ligne
        HAL_GPIO_WritePin(keypad->row_ports[i], keypad->row_pins[i], GPIO_PIN_RESET);

        for(uint8_t j = 0; j < COL_NUMBER; j++) {
            if(HAL_GPIO_ReadPin(keypad->col_ports[j], keypad->col_pins[j]) == GPIO_PIN_RESET) {
                // Petit délai pour l'antirebond
                HAL_Delay(10);
                // Attend que la touche soit relâchée
                while(HAL_GPIO_ReadPin(keypad->col_ports[j], keypad->col_pins[j]) == GPIO_PIN_RESET);
                HAL_GPIO_WritePin(keypad->row_ports[i], keypad->row_pins[i], GPIO_PIN_SET);
                return KEYPAD_MAP[i][j];
            }
        }
        // Désactive la ligne
        HAL_GPIO_WritePin(keypad->row_ports[i], keypad->row_pins[i], GPIO_PIN_SET);
    }
    return '\0';
}
